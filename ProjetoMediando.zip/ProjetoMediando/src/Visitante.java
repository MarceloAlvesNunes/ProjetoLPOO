package src;


import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcelo
 */
public class Visitante extends Pessoa {
    
    //atributos
    private String escolaridade;
    private int telefone;
    private String email;
    
     //Construtores

    public Visitante() {
    }

    public Visitante(String escolaridade, int telefone, String email) {
        this.escolaridade = escolaridade;
        this.telefone = telefone;
        this.email = email;
    }

    public Visitante(int telefone, String email) {
        this.telefone = telefone;
        this.email = email;
    }
    
    //gets e sets
   
    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getNome() {
        return nome;
    }

  @Override
    public void setNome(String nome) {
        this.nome = nome;
    }


  @Override
    public String getNacionalidade() {
        return nacionalidade;
    }

  @Override
    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

  @Override
    public String getSexo() {
        return sexo;
    }

  @Override
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

  @Override
    public String getCidade() {
        return cidade;
    }

  @Override
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }


    //metodos
    
    @Override
    public void exibirDados(){
     }
    
    
}

           