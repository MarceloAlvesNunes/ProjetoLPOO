package src;


import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcelo
 */
public class Aluno extends Pessoa {
    
    //atributos
    
     private String modalidade;
     private String nomeCurso;
     private Curso  curso;
     private String instituicao;
     private String periodoLetivo;



    //Construtores
    
    public Aluno(){
    }

    public Aluno(String modalidade, String nomeCurso, Curso curso, String instituicao, String periodoLetivo) {
        this.modalidade = modalidade;
        this.nomeCurso = nomeCurso;
        this.curso = curso;
        this.instituicao = instituicao;
        this.periodoLetivo = periodoLetivo;
    }

    public Aluno(String nomeCurso, Curso curso, String instituicao) {
        this.nomeCurso = nomeCurso;
        this.curso = curso;
        this.instituicao = instituicao;
    }
    
    //gets e sets
    
    
        public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public String getPeriodoLetivo() {
        return periodoLetivo;
    }

    public void setPeriodoLetivo(String periodoLetivo) {
        this.periodoLetivo = periodoLetivo;
    }
   
     @Override
    public String getNome() {
        return nome;
    }

  @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

  @Override
    public String getNacionalidade() {
        return nacionalidade;
    }

  @Override
    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

  @Override
    public String getSexo() {
        return sexo;
    }

  @Override
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

  @Override
    public String getCidade() {
        return cidade;
    }

  @Override
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

     
    //metodos
   
    public String fModalidade(){
        Object[] itens = { "EAD", "Presencial"};

      Object selectedValue = JOptionPane.showInputDialog(null,
          "Escolha um item", "Opçao",
              JOptionPane.INFORMATION_MESSAGE, null,
                  itens, itens [0]);
         return modalidade;
    }

public String fPeriodo(){
        Object[] itens = { "Manhã", "Tarde", "Noite"};

      Object selectedValue = JOptionPane.showInputDialog(null,
          "Escolha um item", "Opçao",
              JOptionPane.INFORMATION_MESSAGE, null,
                  itens, itens [0]);
         return periodoLetivo;
    }

     @Override
     public void exibirDados(){
     }
}

