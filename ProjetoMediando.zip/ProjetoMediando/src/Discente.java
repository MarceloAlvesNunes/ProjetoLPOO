package src;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcelo
 */
public class Discente extends Pessoa {
   
     //atributos
     private String semestre;
     private int anoIngresso;
     
    //Construtores

    public Discente() {
    }

    public Discente(String semestre, int anoIngresso) {
        this.semestre = semestre;
        this.anoIngresso = anoIngresso;
    }

    public Discente(String semestre) {
        this.semestre = semestre;
    }
    
    
    //gets e sets
   
    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

    @Override
    public String getNome() {
        return nome;
    }

  @Override
    public void setNome(String nome) {
        this.nome = nome;
    }
    

  @Override
    public String getNacionalidade() {
        return nacionalidade;
    }

  @Override
    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

  @Override
    public String getSexo() {
        return sexo;
    }

  @Override
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

  @Override
    public String getCidade() {
        return cidade;
    }

  @Override
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

     
    //metodos
     @Override
    public void exibirDados(){
     }
}
