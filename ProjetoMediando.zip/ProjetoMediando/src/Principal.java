package src;


import java.util.Arrays;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Marcelo
 */
public class Principal {
    static ArrayList<String> cadastro = new ArrayList<String>();
    static String ler = JOptionPane.showInputDialog("");
    public static void main(String[] args) {

       
        
        
        
        
        /*Aluno x = new Aluno();
        Curso y = new Curso();
        y.setCategoria("hjhdjkebjkd");
        y.setGrauAcademico("bjkbjfrb");

        x.setCurso(y);
        x.getCurso().getCategoria();*/

        

        //ArrayList<Aluno> lista = new ArrayList<>();
        //ArrayList<Visitante> lista = new ArrayList<Visitante>();
        

        //Aqui temos um exemplo de Polimofismo de coerção que seria a conversão de um tipo primitivo para outro no caso de String para integer
        int valor;
        do{      
        valor = Integer.parseInt(JOptionPane.showInputDialog(" 1 - Cadastrar \n  2 - Consultar \n 3 - Alterar \n 4 - Excluir \n 5 - Sair"));

        switch (valor) {
            case 1:
                JOptionPane.showInputDialog("1. Ecolheu Cadastrar");
                Aluno novo = new Aluno();
                lista.add(novo);

                //lista.get(0).;
                break;
            case 2:

                JOptionPane.showInputDialog("2.Escolheu Consultar");

                break;
            case 3:
                JOptionPane.showInputDialog("2.Escolheu Alterar");

                break;

            case 4:
                JOptionPane.showInputDialog("2.Escolheu Excluir");

                break;

            case 5:
                Object[] opcoes = {"sim", "não"};
                Object resposta;
                do {
                    resposta = JOptionPane.showInputDialog(null,
                            "Deseja finalizar o programa?",
                            "Finalização",
                            JOptionPane.PLAIN_MESSAGE, null, opcoes, "não");
                } while (resposta == null || resposta.equals("não"));
                
                break;

            default:
                JOptionPane.showMessageDialog(null,"Este não é um valor válido!");
                
        }
      } while (valor !=5);   
    }
    
    public static void Cadastrar() {
    Aluno alunos = new Aluno();
    Visitante visitantes = new Visitante();
    
    JOptionPane.showMessageDialog(null,"Cadastro do Aluno");
    JOptionPane.showMessageDialog(null,"Nome do Curso que frequenta");
    alunos.setNomeCurso(ler);
    
   }
}

/*JOptionPane.showInputMessage(null,"Cadastro do Aluno");

System.out.println("\n[Endereço do Funcionário ]\n");
        System.out.println("Rua:");
        ender1.setRua(tecla.next());*/