package src;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcelo
 */
public class Graduado extends Pessoa {
    
    //atributos
    private int anoConclusao;
    
     //Construtores

    public Graduado() {
    }

    public Graduado(int anoConclusao) {
        this.anoConclusao = anoConclusao;
    }
    
    
    //gets e sets
   
    public int getAnoConclusao() {
        return anoConclusao;
    }

    public void setAnoConclusao(int anoConclusao) {
        this.anoConclusao = anoConclusao;
    }

    @Override
    public String getNome() {
        return nome;
    }

  @Override
    public void setNome(String nome) {
        this.nome = nome;
    }


  @Override
    public String getNacionalidade() {
        return nacionalidade;
    }

  @Override
    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

  @Override
    public String getSexo() {
        return sexo;
    }

  @Override
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

  @Override
    public String getCidade() {
        return cidade;
    }

  @Override
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
     
    //metodos
    @Override
    public void exibirDados(){
     }
}
