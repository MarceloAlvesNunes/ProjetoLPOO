package src;


import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marcelo
 */
public class Curso {
    
    //atributos
    
    private String categoria;
    private String grauAcademico;
    
    
    //Construtores
    
    public Curso(){
    }

    public Curso(String categoria, String grauAcademico) {
        this.categoria = categoria;
        this.grauAcademico = grauAcademico;
    }

    public Curso(String categoria) {
        this.categoria = categoria;
    }
    
    
    
    //sets e gets

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getGrauAcademico() {
        return grauAcademico;
    }

    public void setGrauAcademico(String grauAcademico) {
        this.grauAcademico = grauAcademico;
    }

    
    //metodos
    
     public void fCategoria(){
        Object[] itens = { "Publica", "Privada"};

      Object selectedValue = JOptionPane.showInputDialog(null,
          "Escolha um item", "Opçao",
              JOptionPane.INFORMATION_MESSAGE, null,
                  itens, itens [0]);
    }

 public void fGrauAcademico(){
        Object[] itens = { "Licenciatura", "Bacharelado"};

      Object selectedValue = JOptionPane.showInputDialog(null,
          "Escolha um item", "Opçao",
              JOptionPane.INFORMATION_MESSAGE, null,
                  itens, itens [0]);
    }
    
}
